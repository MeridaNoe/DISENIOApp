package mx.edu.utez.estilos4_a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
// Drawable = Shape, Vector y Selector, Son archivos XML

// Shape permite 4 figuras = rectangulo, ovalo, linea o anillo
// Vector
// Selector permite cambiar la apariencia de un control de acuerdo a su estado
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}