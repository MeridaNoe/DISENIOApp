package mx.edu.utez.mensajes4_a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edt1 = findViewById<EditText>(R.id.edt1)
        val btnToast = findViewById<Button>(R.id.btnToast)
        val btnAlert = findViewById<Button>(R.id.btnAlert)
        val btnLog = findViewById<Button>(R.id.btnLog)
        val btnSnack = findViewById<Button>(R.id.btnSnack)

        btnToast.setOnClickListener {
            Toast.makeText(this@MainActivity,
                edt1.text.toString(),
                Toast.LENGTH_SHORT
                ).show()
        }
        btnAlert.setOnClickListener {
            val builder = AlertDialog.Builder(this@MainActivity)
            builder.setTitle("Este es el titulo")
            builder.setMessage(edt1.text.toString())
            builder.setPositiveButton("NO"){dialog, _ ->
                dialog.dismiss()
            }
            builder.setNegativeButton("SI"){dialog, _ ->
                dialog.dismiss()
            }
            builder.setNeutralButton("Mas Tarde"){dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }

        btnLog.setOnClickListener {
            Log.e("Error", edt1.text.toString())
            Log.i("Info", edt1.text.toString())
            Log.w("Warning", edt1.text.toString())

        }
        btnSnack.setOnClickListener {
            val snack = Snackbar.make(
                findViewById(R.id.constraint), // <- no se usa contexto
                // Se coloca la viusta a la cual se pega el snackbar
                edt1.text.toString(),
                Snackbar.LENGTH_SHORT
            )
            snack.setAction("Boton"){
                println("uwu")
            }
            snack.show()
        }

    }
}