package mx.edu.utez.examen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edt_Num1 = findViewById<EditText>(R.id.edt_Num1)
        val edt_Num2 = findViewById<EditText>(R.id.edt_Num2)
        val edt_Num3 = findViewById<EditText>(R.id.edt_Num3)
        val edt_Num4 = findViewById<EditText>(R.id.edt_Num4)
        val edt_Num5 = findViewById<EditText>(R.id.edt_Num5)
        val edt_Num6 = findViewById<EditText>(R.id.edt_Num6)
        val edt_Num7 = findViewById<EditText>(R.id.edt_Num7)
        val edt_Num8 = findViewById<EditText>(R.id.edt_Num8)
        val edt_Num9 = findViewById<EditText>(R.id.edt_Num9)

        val btn_Limpiar = findViewById<Button>(R.id.btn_limpiar)
        val btn_Calcular = findViewById<Button>(R.id.btn_Calcular)

        val txt_Fila1 = findViewById<TextView>(R.id.txt_Fila1)
        val txt_Fila2 = findViewById<TextView>(R.id.txt_Fila2)
        val txt_Fila3 = findViewById<TextView>(R.id.txt_Fila2)
        val Diagonal1 = findViewById<TextView>(R.id.txt_Diagonal)
        val Columna1 = findViewById<TextView>(R.id.txt_Fila5)
        val Columna2 = findViewById<TextView>(R.id.txt_Fila6)
        val Columna3 = findViewById<TextView>(R.id.txt_Fila7)

        val txt_Area = findViewById<TextView>(R.id.text_Area)

        val res = 0

        btn_Limpiar.setOnClickListener {
            edt_Num1.text.clear()
            edt_Num2.text.clear()
            edt_Num3.text.clear()
            edt_Num4.text.clear()
            edt_Num5.text.clear()
            edt_Num6.text.clear()
            edt_Num7.text.clear()
            edt_Num8.text.clear()
            edt_Num9.text.clear()

        }


        btn_Calcular.setOnClickListener {
            if (edt_Num1.text.isEmpty() && edt_Num2.text.isEmpty() && edt_Num3.text.isEmpty() && edt_Num4.text.isEmpty() && edt_Num5.text.isEmpty() && edt_Num6.text.isEmpty()
                && edt_Num7.text.isEmpty() && edt_Num8.text.isEmpty() && edt_Num9.text.isEmpty()){

                Toast.makeText(txt_Area, this@MainActivity,
                "llene los campos",
                    Toast.LENGTH_SHORT
                ).show()

            }

        }



    }
}


