package mx.edu.utez.login4_a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val chkOctane = findViewById<CheckBox>(R.id.chkOctane)
        val rgOpciones = findViewById<RadioGroup>(R.id.rgOpciones)
        val rbtn1 = findViewById<RadioButton>(R.id.rbtn1)
        val rbtnDrogo = findViewById<RadioButton>(R.id.rbtnDrogo)
        val btnAceptar = findViewById<Button>(R.id.btnAceptar)
    }




}