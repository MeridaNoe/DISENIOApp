package mx.edu.utez.login4_a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_linear)

        val edtUsuario = findViewById<EditText>(R.id.edt_Usuario)
        val edtContrasena = findViewById<EditText>(R.id.edtContra)
        val btnIniciar = findViewById<Button>(R.id.btnIniciar)
        val btnOlvidar = findViewById<Button>(R.id.btnOlvidar)

        // function suma(x, y){
        //      return x + y;
        // }
        // const suma = (x,y) => {
        //      return x + y;
        // }


        btnIniciar.setOnClickListener {
            // la unica excepcion es el EditText
            /*edtUsuario.setText("Hola Mundo!")
            println("holaaaaa")*/
            //Clase para abirir componentes nuevos Intent <- 1. Origen 2. Destino...
            //Intent intent = new Intent();
            val intent = Intent(this@MainActivity,
            Home::class.java)
            startActivity(intent)
        }

        Toast.makeText(
            this@MainActivity,
            "texto de ejemplo",
            Toast.LENGTH_SHORT
        ).show()


        btnOlvidar.setOnClickListener {
           /* edtContrasena.setText("Olvidaste tu contrasenña")
            println("Olvidaste tu contrasenña")*/
        }


    }



}