package mx.edu.utez.miprimerapp4a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//class MainActivity extends AppCompatActivity
class MainActivity : AppCompatActivity() {
    //@Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}


/*
int suma (int x, int y){
    return x+y;
}
*/
//Unit
//              Tipo de retonro de la funcion
fun suma (x: Int, y:Int): Int {
    return x + y
}

fun variables(){
    // int x = 0;
    // var (cambian) / val (no cambian)
    var x = true
    var y : Int = 0
    var z : Boolean = false
    //? operador que permite asignar nulos a una variable
    // si la variable tiene nulo, no ejecutara la linea
    // si es distinto, lo ejecuta
    var objeto : String? = null
}


// ESTRUCTURAS DE CONTROL
// if, switch

fun control(){
    val condicion = true
    var mensaje = ""
    if (condicion){
        mensaje = "ok"
    }else{
        mensaje = "no ok"
    }
    println(mensaje)


    when(mensaje){
        "OK" -> {  } // si solo es una linea, no lleva {}
        "No ok" -> {  }
        else -> {  }
    }
}

// ciclos
// do, dowhile.

fun ciclos(){
    val condicion = true
    while (condicion){  }

    do{

    }while (condicion)
    // for (int x = 0; x< 10; x++)
    for (x in 0.. 10 step 1){

    }
}

