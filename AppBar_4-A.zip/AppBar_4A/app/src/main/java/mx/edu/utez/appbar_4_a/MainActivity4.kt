package mx.edu.utez.appbar_4_a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.appbar_4_a.databinding.ActivityMain4Binding

class MainActivity4 : AppCompatActivity() {
    lateinit var binding: ActivityMain4Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain4Binding.inflate(layoutInflater)



        setContentView(binding.root)


       binding.btnSig1.setOnClickListener {
            val intent = Intent(this@MainActivity4, MainActivity::class.java)
           // ESTE  -----------------\ LIMPIA LA PILA
           intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or
                   // ESTE HACE QUE CREE UNO NUEVO PARA METER LA PRIMERA PANTALLA.
                   Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }



    }
}