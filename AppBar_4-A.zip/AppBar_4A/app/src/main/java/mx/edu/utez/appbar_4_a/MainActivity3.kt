package mx.edu.utez.appbar_4_a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.appbar_4_a.databinding.ActivityMain3Binding
import mx.edu.utez.appbar_4_a.databinding.ActivityMainBinding

class MainActivity3 : AppCompatActivity() {
    lateinit var binding: ActivityMain3Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain3Binding.inflate(layoutInflater)



        setContentView(binding.root)


      binding.btnSig3.setOnClickListener {
            val intent = Intent(this@MainActivity3, MainActivity4::class.java)
            startActivity(intent)
        }



    }
}