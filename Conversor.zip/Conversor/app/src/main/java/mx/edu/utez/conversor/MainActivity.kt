package mx.edu.utez.conversor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val datos = listOf("USD", "MXN","JPY","CAD","EUR")
        val spOrigen = findViewById<Spinner>(R.id.spOrigen)
        val btnConvertir = findViewById<Button>(R.id.btnConvertir)
        val spDestino = findViewById<Spinner>(R.id.spDestino)
        val edtCantidad = findViewById<EditText>(R.id.edtCantidad)
        val txtResultado =findViewById<TextView>(R.id.txtResultado)
        val adaptador = ArrayAdapter(this@MainActivity,
            android.R.layout.simple_list_item_1,
            datos
        )

        spOrigen.adapter = adaptador
        spDestino.adapter = adaptador

        btnConvertir.setOnClickListener {
            val cantidad = edtCantidad.text.toString().toDouble()
            val origen = spOrigen.selectedItem.toString()
            val destino = spDestino.selectedItem.toString()

            if (origen == "MXN" && destino == "USD"){
                txtResultado.text = (cantidad * 0.05).toString()
            }else if (origen == "MXN" && destino == "JPY"){
                
            }
        }


    }
}