package mx.edu.utez.recuperacion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.coroutines.selects.select

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edt1 = findViewById<EditText>(R.id.edt1)
        val edt2 = findViewById<EditText>(R.id.edt2)
        val btn = findViewById<Button>(R.id.btn)
        val spin= findViewById<Spinner>(R.id.spin)
        val txt = findViewById<TextView>(R.id.textView)
        val btn2 = findViewById<Button>(R.id.btn2)

  val datos = listOf("+","-","*","/")
        val adaptador = ArrayAdapter(this@MainActivity,
            android.R.layout.simple_list_item_1,
            datos
        )
        spin.adapter = adaptador
        btn.setOnClickListener {
if(edt1.text.toString()=="" && edt2.text.toString()==""){
    txt.setText("igresa un numero ")
}else {



     var origen = spin.selectedItem


      var   cantidad = edt1.text.toString().toDouble()
            var cantidad2 = edt2.text.toString().toDouble()



            when(origen){


                "+" -> cantidad = cantidad + cantidad2
                "-" -> cantidad = cantidad - cantidad2
                "*" -> cantidad = cantidad * cantidad2
                "/" -> cantidad = cantidad / cantidad2
            }

      txt.setText(cantidad.toString())
        }
        btn2.setOnClickListener {
            edt1.setText("")
            edt2.setText("")
            txt.setText("")
        }
    }

    }


}